package com.jpa.employeeDetails;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class PersistEmployee {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Employee_details");
		EntityManager em = emf.createEntityManager();
		Employee emp = em.find(Employee.class, 1);

		System.out.println("Employeet id = " + emp.getEmp_id());
		System.out.println("Employee name = " + emp.getName());
		System.out.println("Designation = " + emp.getDesignation());

	}

}
