package com.jpa.employeeDetails;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class PersistEmployee {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Employee_details");
		EntityManager em = emf.createEntityManager();

		em.getTransaction().begin();

		Employee emp1 = new Employee();
		emp1.setEmp_id(1);
		emp1.setName("Akash");
		emp1.setDesignation("PA");

		Employee emp2 = new Employee();
		emp2.setEmp_id(2);
		emp2.setName("Aki");
		emp2.setDesignation("PAT");

		Employee emp3 = new Employee();
		emp3.setEmp_id(3);
		emp3.setName("Chopi");
		emp3.setDesignation("PA");

		em.persist(emp1);
		em.persist(emp2);
		em.persist(emp3);

		em.getTransaction().commit();
		emf.close();
		em.close();

	}

}
