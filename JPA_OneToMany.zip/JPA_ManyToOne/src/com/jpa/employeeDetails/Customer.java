package com.jpa.employeeDetails;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table
public class Customer {
	@Id
	private int cus_id;
	private String cus_name;
	@OneToMany(targetEntity = Order.class)
	private List<Order> Orders;

	public int getCus_id() {
		return cus_id;
	}

	public void setCus_id(int cus_id) {
		this.cus_id = cus_id;
	}

	public String getCus_name() {
		return cus_name;
	}

	public void setCus_name(String cus_name) {
		this.cus_name = cus_name;
	}

	public List<Order> getOrders() {
		return Orders;
	}

	public void setOrders(List<Order> orders) {
		Orders = orders;
	}

	public Customer(int cus_id, String cus_name, List<Order> orders) {
		super();
		this.cus_id = cus_id;
		this.cus_name = cus_name;
		Orders = orders;
	}

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}

}