package com.jpa.employeeDetails;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class OneToMany {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Orders");
		EntityManager em = emf.createEntityManager();

		em.getTransaction().begin();

		Order ord1 = new Order();
		ord1.setOrder_id(100);

		Order ord2 = new Order();
		ord2.setOrder_id(200);

		em.persist(ord1);
		em.persist(ord2);

		ArrayList<Order> orders = new ArrayList<Order>();

		Customer cus1 = new Customer();
		cus1.setCus_id(1);
		cus1.setCus_name("Jany");
		cus1.setOrders(orders);

		em.persist(cus1);

		em.getTransaction().commit();

		em.close();
		emf.close();
	}

}
