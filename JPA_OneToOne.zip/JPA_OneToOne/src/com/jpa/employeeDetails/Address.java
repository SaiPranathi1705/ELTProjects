package com.jpa.employeeDetails;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table
public class Address {
@Id
	private int add_id;
	private String country;
	private double pinCode;
	
	public Address(int add_id, String country, double pinCode) {
		super();
		this.add_id = add_id;
		this.country = country;
		this.pinCode = pinCode;
	}
	public int getAdd_id() {
		return add_id;
	}
	public void setAdd_id(int add_id) {
		this.add_id = add_id;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public double getPinCode() {
		return pinCode;
	}
	public void setPinCode(double pinCode) {
		this.pinCode = pinCode;
	}
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
	
	
	