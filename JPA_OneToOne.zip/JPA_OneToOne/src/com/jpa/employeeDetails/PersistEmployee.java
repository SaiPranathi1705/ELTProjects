package com.jpa.employeeDetails;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class PersistEmployee {

	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("Employee_details");
		EntityManager em = emf.createEntityManager();
		 em.getTransaction( ).begin( );  
         
		 
		 Address add1=new Address(); 
		 add1.setAdd_id(101);
         add1.setCountry("India");
         add1.setPinCode(600052);

		 Address add2=new Address(); 
		 add2.setAdd_id(102);
         add2.setCountry("US");
         add2.setPinCode(900123);
       
         em.persist(add1);
         em.persist(add2);
         
         Employee emp1=new Employee();  
         emp1.setEmp_id(1); 
         emp1.setName("Akash");
         emp1.setDesignation("PA");
         emp1.setAddress(add1);
           
         Employee emp2=new Employee();  
         emp2.setEmp_id(2); 
         emp2.setName("Aki");
         emp2.setDesignation("PAT");
         emp2.setAddress(add2);
           
         em.persist(emp1); 
         em.persist(emp2);  
           
         em.getTransaction().commit();  
           
         em.close();  
         emf.close();  
  }  
    
    
}  
