package com.task4.dao;

import java.util.List;

import com.task4.model.Book;

public interface bookDao {

	public boolean createBook();

	public int persistBook(List<Book> bookList);

	public Book findBook(Integer id);

}
