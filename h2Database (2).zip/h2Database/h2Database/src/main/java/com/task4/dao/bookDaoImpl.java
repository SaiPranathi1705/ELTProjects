package com.task4.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.stereotype.Component;

import com.task4.model.Book;

@Component
public class bookDaoImpl {

	static final String JDBC_DRIVER = "org.h2.Driver";
	// static final String DB_URL = "jdbc:h2:~/test";
	static final String DB_URL = "jdbc:h2:tcp://localhost/~/test";
	static final String USER = "sa";
	static final String PASS = "";

	private static final String CREATE_BOOK = "CREATE TABLE BOOK" + "(id BIGINT NOT NULL, "
			+ " description VARCHAR(255), " + " isbn VARCHAR(255), " + " nbOfPages INTEGER, " + " title VARCHAR(255), "
			+ " unitCost DOUBLE, " + " PRIMARY KEY ( id ))";

	private static final String PERSIST_BOOK = "INSERT INTO Book " + "VALUES ( ?, ?, ?, ?, ?, ?)";

	private static final String FIND_BOOK = "SELECT description, isbn, nbOfPages, title, unitCost FROM Book WHERE id=?";

	public boolean createBook() throws Exception {
		droptable();

		Connection conn = null;
		Statement stmt = null;
		try {

			Class.forName(JDBC_DRIVER);

			System.out.println("Connecting to database...");
			conn = DriverManager.getConnection(DB_URL, USER, PASS);

			System.out.println("Creating table in given database...");
			stmt = conn.createStatement();

			stmt.executeUpdate(CREATE_BOOK);

			System.out.println("Created table in given database...");

			stmt.close();
			conn.close();
		} catch (SQLException se) {

			se.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException se2) {
			}
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
		System.out.println("Book Table created Successfully!");
		return true;
	}

	public int persistBook(Book book) {
		Connection conn = null;
		// PreparedStatement stmt = null;
		Statement stmt = null;
		int count = 0;
		try {

			Class.forName(JDBC_DRIVER);
			System.out.println("Connecting to a selected database...");
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			stmt = conn.prepareStatement(PERSIST_BOOK);
			stmt = conn.createStatement();
			String sql = "INSERT INTO Book "
					+ "VALUES ( 1, 'Spring boot concepts' ,'spring', 200,'Spring boot Fundamentals',500)";
			stmt.executeUpdate(sql);
			sql = "INSERT INTO Book " + "VALUES ( 2, 'Java concepts' ,'java', 300,'Java Fundamentals',500)";
			stmt.executeUpdate(sql);
			System.out.println("Connected database successfully...");
			System.out.println("Inserted records into the table...");
			stmt.close();
			conn.close();

		} catch (SQLException se) {

			se.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException se2) {
			}
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
		System.out.println("Goodbye!");
		return count;
	}

	public Book findBook(Integer id) {

		Connection conn = null;
		PreparedStatement stmt = null;
		try {

			Class.forName(JDBC_DRIVER);

			System.out.println("Connecting to database...");
			conn = DriverManager.getConnection(DB_URL, USER, PASS);

			System.out.println("Connected database successfully...");
			stmt = conn.prepareStatement(FIND_BOOK);
			stmt.setLong(1, id);
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {

				String description = rs.getString("description");
				String isbn = rs.getString("isbn");
				int nbOfPages = rs.getInt("nbOfPages");
				String title = rs.getString("title");
				double unitCost = rs.getDouble("unitCost");
				System.out.print(", Id: " + id);
				System.out.print(", Description: " + description);
				System.out.print(", Isbn: " + isbn);
				System.out.println(", nbOfPages: " + nbOfPages);
				System.out.println(", Title: " + title);
				System.out.println(", UnitCost: " + unitCost);

			}

			rs.close();
		} catch (SQLException se) {

			se.printStackTrace();
		} catch (Exception e) {

			e.printStackTrace();
		} finally {

			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException se2) {
			} // nothing we can do
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
		System.out.println("Goodbye!");
		return null;
	}

	public void droptable() throws Exception {
		Connection conn = null;
		Statement stmt = null;
		try {

			Class.forName(JDBC_DRIVER);

			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			stmt = conn.createStatement();
			String sql = "DROP TABLE Book";
			stmt.executeUpdate(sql);

		} finally {

			try {
				if (stmt != null)
					stmt.close();
			} catch (SQLException se2) {
			} // nothing we can do
			try {
				if (conn != null)
					conn.close();
			} catch (SQLException se) {
				se.printStackTrace();
			}
		}
		System.out.println("drop!");

	}
}
