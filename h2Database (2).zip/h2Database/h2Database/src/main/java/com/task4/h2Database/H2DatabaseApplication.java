package com.task4.h2Database;

import java.io.BufferedReader;
import java.io.InputStreamReader;

import com.task4.dao.bookDaoImpl;
import com.task4.model.Book;

public class H2DatabaseApplication {

	public static void main(String[] args) throws Exception {

		bookDaoImpl daoImpl = new bookDaoImpl();
		daoImpl.createBook();
		System.out.println("Enter the Book id");
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
			int i = Integer.parseInt(bf.readLine());
		daoImpl.persistBook(new Book(1, "Spring boot concepts", "Spring", 250, "Spring boot Fundamentals", 500));
		daoImpl.findBook(i);

	}

}
