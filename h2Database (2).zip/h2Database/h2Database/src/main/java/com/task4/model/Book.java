package com.task4.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

@Component
@Entity
public class Book {
	@Id
	private long id;
	private String description;
	private String isbn;
	private Integer nbOfPages;
	private String title;
	private double unitCost;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		description = description;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public Integer getNbOfPages() {
		return nbOfPages;
	}

	public void setNbOfPages(Integer nbOfPages) {
		this.nbOfPages = nbOfPages;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public double getUnitCost() {
		return unitCost;
	}

	public void setUnitCost(double unitCost) {
		this.unitCost = unitCost;
	}

	public Book(long id, String description, String isbn, Integer nbOfPages, String title, double unitCost) {
		super();
		id = id;
		description = description;
		this.isbn = isbn;
		this.nbOfPages = nbOfPages;
		this.title = title;
		this.unitCost = unitCost;
	}

	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}

}
