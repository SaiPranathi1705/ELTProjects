package com.example.processAPI;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProcessApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
